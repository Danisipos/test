﻿using Core.Services;
using Core.Services.Impl;
using System;
using System.Threading;

namespace LogUsers
{
    public class Program
    {
        public static void Main()
        {
            //just for testing purposes, to keep track of only the new log files
            string path = @"C:\LogTest\";

            if (System.IO.Directory.Exists(path))
            {
                System.IO.Directory.Delete(path, true);
            }
            ILog logger = new AsyncLog(new LoglineBuilder(), new OutputWithStartegy(new FileStore(path),new MidnightBasedStrategy()));

            for (var i = 0; i < 15; i++)
            {
                logger.QueueLine("Number with Flush: " + i);
                Thread.Sleep(70);
            }

            logger.StopWithFlush();

            ILog logger2 = new AsyncLog(new LoglineBuilder(), new OutputWithStartegy(new FileStore(path), new MidnightBasedStrategy()));

            for (var i = 50; i > 0; i--)
            {
                logger2.QueueLine("number with no flush: " + i);
                Thread.Sleep(20);
            }

            logger2.StopWithoutFlush();
            Console.ReadLine();
        }
    }
}
