﻿using Core.Services;
using System;

namespace Tests.TestServices
{
    public class PatternBasedStrategy : IOutputStrategy
    {
        private int _internalIncrement=-1;

        public string StrategyId => DateTime.Now.ToString("yyyyMMdd HHmmss fff")+_internalIncrement;

        public bool IsStrategyValid()
        {
            _internalIncrement ++;
            return _internalIncrement % 5 == 0;
        }

        public void UpdateInternalState()
        {
           
        }
    }
}
