﻿using Core.Services;
using System;
using System.Collections.Generic;


namespace Tests.TestServices
{
    /// <summary>
    /// this implementation may be irrelevant 
    /// it is only to ilustrate that logs can also be written somewhere else other than in files.
    /// </summary>
    public class ArrayStore : IOutputStore
    {
        public List<List<string>> OutputList = new List<List<string>>();

        public void CreateNew (string target)
        {
            var loglineInstance = new List<string>();
            loglineInstance.Add("Timestamp".PadRight(25, ' ') + "\t" + "Data".PadRight(15, ' ') + "\t" + Environment.NewLine);
            OutputList.Add(loglineInstance);
        }

        public void Write(string s)
        {
            if (OutputList.Count == 0)
            {
                Initialize(null);
            }
            OutputList[OutputList.Count-1].Add(s);
        }

        public void Close()
        {
        }

        public void Initialize(string target)
        {
            CreateNew(target);
        }
    }
}
