﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Core.Services.Impl;
using NUnit.Framework;
using Tests.TestServices;

namespace Tests
{
    public class Test
    {
        [Test]
        public async Task IsSomethingWritten()
        {
            //clean up folder
            var folderPath = @"C:\LogTest\TestIsSomethingWritten";
            if (Directory.Exists(folderPath))
            {
                Directory.Delete(folderPath, true);
            }
            var logger= new AsyncLog(new LoglineBuilder(), new OutputWithStartegy(new FileStore(folderPath), new MidnightBasedStrategy()));
            logger.QueueLine("test");
            await logger.StopWithFlush();

            var filesInDir = Directory.GetFiles(folderPath);
            var isSomethingWritten = false;
            foreach (var file in filesInDir)
            {
                var text = File.ReadAllText(file);
                if (!string.IsNullOrEmpty(text))
                {
                    isSomethingWritten = true;
                    break;
                }
            }

            Assert.IsTrue(isSomethingWritten);
        }

        [Test]
        public async Task TestStopBehaviourWithArrayAndNoStrategy()
        {
            var output1 = new ArrayStore();
            var logger1 = new AsyncLog(new LoglineBuilder(), output1);
            const int count1 = 15;

            for (var i = 0; i < count1; i++)
            {
                logger1.QueueLine("Number with Flush: " + i);
                Thread.Sleep(50);
            }

            await logger1.StopWithFlush();

            var output2 = new ArrayStore();
            var logger2 = new AsyncLog(new LoglineBuilder(), output2);
            const int count2 = 50;
            for (var i = count2; i > 0; i--)
            {
                logger2.QueueLine("Number with No flush: " + i);
                Thread.Sleep(20);
            }

            await logger2.StopWithoutFlush();

            Console.WriteLine(output1.OutputList[0].Count +" "+ (count1 + 1));
            Console.WriteLine(output2.OutputList[0].Count +" "+ (count2 + 1));

            Assert.IsTrue(output1.OutputList[0].Count == count1 + 1);
            Assert.IsTrue(output2.OutputList[0].Count <= count2 + 1);
        }

        [Test]
        public async Task IsNewFileCreatedWhenMidnight()
        {
            //clean up folder
            var folderPath = @"C:\LogTest\TestIsMidnight";
            if (Directory.Exists(folderPath))
            {
                Directory.Delete(folderPath, true);
            }
            var logger1 = new AsyncLog(new LoglineBuilder(), new OutputWithStartegy(new FileStore(folderPath),new PatternBasedStrategy()));
            const int count1 = 15;

            for (var i = 0; i < count1; i++)
            {
                logger1.QueueLine("Number with Flush: " + i);
                Thread.Sleep(50);
            }

            await logger1.StopWithFlush();
            var filesInDir = Directory.GetFiles(folderPath);
            Assert.IsTrue(filesInDir.Length > 1);

        }

        [Test]
        public async Task TestStopBehaviourWithFileOutputAndNoStrategy()
        {
            const string folderPath = @"C:\LogTest\TestStopeBehaviourNoStrategy";
            // cleanup folder
            if (Directory.Exists(folderPath))
            {
                Directory.Delete(folderPath, true);
            }
            var logger1 = new AsyncLog(new LoglineBuilder(),new FileStore(folderPath));
            const int count1 = 15;


            for (var i = 0; i < count1; i++)
            {
                logger1.QueueLine("Number with Flush: " + i);
                Thread.Sleep(70);
            }

            await logger1.StopWithFlush();

            var logger2 = new AsyncLog(new LoglineBuilder(),new FileStore(folderPath));
            const int count2 = 50;
            for (var i = count2; i > 0; i--)
            {
                logger2.QueueLine("Number with No flush: " + i);
                Thread.Sleep(20);
            }

            await logger2.StopWithoutFlush();

            // read lines from written files
            var filesInDir = Directory.GetFiles(folderPath);
            var writtenLoglines1 = File.ReadAllLines(filesInDir[0]);
            var writtenLoglines2 = File.ReadAllLines(filesInDir[1]);

            Assert.IsTrue(writtenLoglines1.Length == count1+1); // +1 bc of headers
            Assert.IsTrue(writtenLoglines2.Length <= count2+1);
        }
    }

}
