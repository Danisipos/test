﻿namespace Core.Services
{   /// <summary>
    /// Interface used for writing the logfiles
    /// </summary>
    public interface IOutput
    {
        void Initialize(string target);
        void Write(string s);
        void Close();
    }
}
