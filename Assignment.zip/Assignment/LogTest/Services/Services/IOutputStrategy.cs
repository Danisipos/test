﻿namespace Core.Services
{
    /// <summary>
    /// Interface used for triggering when a new file should be created
    /// </summary>
    public interface IOutputStrategy
    {
        string StrategyId { get; }
        bool IsStrategyValid();
        void UpdateInternalState();
    }
}
