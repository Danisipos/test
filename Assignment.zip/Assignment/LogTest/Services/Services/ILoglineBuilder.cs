﻿
using Core.Models;

namespace Core.Services
{
    /// <summary>
    /// Interface for converting logline to string
    /// </summary>
    public interface ILoglineBuilder
    {
        string BuildContent(LogLine logLine);
    }
}