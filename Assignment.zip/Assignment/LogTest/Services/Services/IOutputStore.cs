﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    /// <summary>
    /// interface used for defining the actual storage of the logline and can be used as IOutput if needed
    /// </summary>
    public interface IOutputStore: IOutput
    {
        void CreateNew(string tragetName);
    }
}
