﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Core.Services.Impl
{
    /// <summary>
    /// Actual implementation of file storage with filecreation and writing
    /// </summary>
    public class FileStore : IOutputStore
    {
        private readonly List<StreamWriter> _writers = new List<StreamWriter>();
        private readonly string _folderPath;

        public FileStore(string folderPath)
        {
            _folderPath = folderPath;
        }

        public void Initialize(string target)
        {
            CreateNew(target);
        }

        public void CreateNew(string targetName)
        {
            if (!Directory.Exists(_folderPath))
            {
                Directory.CreateDirectory(_folderPath);
            }
            var writer = File.AppendText(_folderPath + "\\Log" + targetName + ".log");
            writer.AutoFlush = true;
            writer.Write("Timestamp".PadRight(25, ' ') + "\t" + "Data".PadRight(15, ' ') + "\t" + Environment.NewLine);
            Close();
            _writers.Add(writer);
        }

        public void Write(string s)
        {
            if (_writers.Count == 0)
            {
                Initialize("DefaultFileStore " + DateTime.Now.ToString("yyyyMMdd HHmmss fff"));
            }
            _writers[_writers.Count - 1].Write(s); 
        }

        public void Close()
        {
            if (_writers.Count > 0)
            {
                _writers[_writers.Count - 1].Close();
            }
        }

        
    }
}
