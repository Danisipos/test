﻿namespace Core.Services.Impl
{
    /// <summary>
    /// Class that extends IOutput just like Outputstorage but contanins a strategy on how a new files are created
    /// </summary>
    public class OutputWithStartegy : IOutput
    {
        private readonly IOutputStore _store;
        private readonly IOutputStrategy _newOutputStrategy;

        public OutputWithStartegy(IOutputStore store, IOutputStrategy newOutputStrat)
        {
            _store = store;
            _newOutputStrategy = newOutputStrat;
         
        }

        public void Initialize(string target)
        {
            FollowStrategy();
        }

        private void FollowStrategy()
        {
            if (_newOutputStrategy.IsStrategyValid())
            {
                _store.CreateNew(_newOutputStrategy.StrategyId);
                _newOutputStrategy.UpdateInternalState();
            }
        }

        public void Write(string s)
        {
            FollowStrategy();
            _store.Write(s);
        }

        public void Close()
        {
            _store.Close();
        }


    }
}
