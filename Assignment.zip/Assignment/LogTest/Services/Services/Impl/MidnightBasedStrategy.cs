﻿using System;

namespace Core.Services.Impl
{
    public class MidnightBasedStrategy : IOutputStrategy
    {
        private DateTime _currentDate = DateTime.MinValue;

        public string StrategyId => DateTime.Now.ToString("yyyyMMdd HHmmss fff");

        public bool IsStrategyValid()
        {
            return (DateTime.Now - _currentDate).Days != 0;
        }

        public void UpdateInternalState()
        {
            _currentDate = DateTime.Now;
        }
    }
}
