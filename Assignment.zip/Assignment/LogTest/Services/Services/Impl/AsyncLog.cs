﻿using Core.Models;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Services.Impl
{
    public class AsyncLog : ILog
    {
        private readonly ILoglineBuilder _loglineFactory;
        private IOutput _output { get; }
        private readonly ConcurrentQueue<LogLine> _lines = new ConcurrentQueue<LogLine>();
        private bool _quitWithFlush;
    
        private  Task _task= Task.CompletedTask;

        private CancellationTokenSource _tokenSource;

        public async Task StopWithoutFlush()
        {
            _tokenSource.Cancel();
            _tokenSource.Dispose();
            await _task;
            _output.Close(); // always close output when closing the logger
        }

        public async Task StopWithFlush()
        {
            _quitWithFlush = true;
            await _task;
            _output.Close(); // always close output when closing the logger
        }

        public void QueueLine(string text)
        {
            if (!_quitWithFlush && !_tokenSource.IsCancellationRequested)  // if any are true then log is shutting down and data is ignored
            {
                _lines.Enqueue(new LogLine(text, DateTime.Now));
                if (_task.IsCompleted) // only start a new one if the loop is not running already otherwise the loop will pick the data as it comes
                {
                    _task = Task.Run(async () => await MainLoop(_tokenSource), _tokenSource.Token);
                }
            }
        }

        public AsyncLog(ILoglineBuilder loglineFactory, IOutput output)
        {
            _loglineFactory = loglineFactory;
            _output = output;
            _tokenSource = new CancellationTokenSource();
        }

        private async Task MainLoop(CancellationTokenSource token)
        {
            LogLine logLine = null;
            while (!token.IsCancellationRequested &&_lines.TryDequeue(out logLine)) // stop if canceled requested or q is empty
            {
                try
                {
                    _output.Write(_loglineFactory.BuildContent(logLine)); // all writing related code is in this line
                }
                catch (Exception e)
                {
                   // handle error
                    Console.WriteLine(e);
                }
                finally
                {
                    if (!token.IsCancellationRequested) // save 50 ms if somehow its canceled inside the loop;
                    {
                        await Task.Delay(50);
                    }
                }
            }
          
        }
    }
}