﻿using Core.Models;
using System;
using System.Text;

namespace Core.Services.Impl
{
    public class LoglineBuilder : ILoglineBuilder
    {
        public string BuildContent(LogLine logLine)
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.Append(logLine.Timestamp.ToString("yyyy-MM-dd HH:mm:ss:fff"));
            stringBuilder.Append("\t");
            stringBuilder.Append(logLine.LineText());
            stringBuilder.Append("\t");
            stringBuilder.Append(Environment.NewLine);

            return stringBuilder.ToString();
        }
    }
}
